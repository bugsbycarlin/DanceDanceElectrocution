
//
// preload.js is glue to allow the app's javascript environment to communicate with the
// electron wrapper's javascript environment in a sandboxed manner.
//
// Copyright 2022 Alpha Zoo LLC.
// Written by Matthew Carlin
//

